package com.library.backend.entity.enums;

public enum RoleType {
    ADMIN,
    USER,
    LIBRARIAN
}

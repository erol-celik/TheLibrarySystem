package com.library.backend.entity.enums;

//işlemin türünü belirler
public enum TransactionType {
    PURCHASE,
    PENALTY_PAYMENT,
    DONATION,
    //aklımıza gelirse eklenebilir
}

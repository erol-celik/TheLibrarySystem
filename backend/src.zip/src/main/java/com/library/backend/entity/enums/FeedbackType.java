package com.library.backend.entity.enums;

public enum FeedbackType {
    COMPLAINT,
    SUGGESTION
}

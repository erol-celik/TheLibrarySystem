package com.library.backend.entity.enums;

public enum BookSaleType {
    DIGITAL_COPY,
    PHYSICAL_COPY,
}

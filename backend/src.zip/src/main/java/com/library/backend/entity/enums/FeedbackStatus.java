package com.library.backend.entity.enums;

public enum FeedbackStatus {
    NEW,
    IN_PROGRESS,
    RESOLVED
}
